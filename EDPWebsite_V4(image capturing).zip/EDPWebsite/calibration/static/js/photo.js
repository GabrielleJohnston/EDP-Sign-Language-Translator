(function(){
  //Defining the variables in JavaScript
  var video = document.getElementById('video'),
    canvas = document.getElementById('canvas'),
    context = canvas.getContext('2d'),
    photo = document.getElementById('photo'),
    vendorUrl = window.URL || window.webkitURL;
  //Getting users permision for the camera in different browsers
  navigator.getMedia =  (navigator.getUserMedia ||
                        navigator.webkitGetUserMedia ||
                        navigator.mozGetUserMedia ||
                        navigator.msGetUserMedia);

//Method to get media(eg. video, audio...)
  navigator.getMedia({
    //Setting the parameters in getmedia method
    video: true,
    audio: false
  }, function(stream){
    //Getting the video stream and displaying it
    video.srcObject=stream;
    video.play();
  }, function(error){
    //An error occured - we dont need this for now
    //error.code
  });

  //Capturing and displaying the photo (also converting to img from canvas)
  document.getElementById('capture').addEventListener('click', function() {
    context.drawImage(video, 0, 0, 400, 300);
    photo.setAttribute('src', canvas.toDataURL('image/png'));
  })

})();
