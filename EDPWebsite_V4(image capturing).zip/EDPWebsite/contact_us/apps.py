#settings file for this app

from django.apps import AppConfig


class ContactUsConfig(AppConfig):
    name = 'contact_us'
