# ENSURE THAT shape_predictor_68_face_landmarks.dat FILE IS IN THE SAME
# DIRECTORY AS THE CODE, OR THAT PATH IS CHANGED

# ENSURE THAT ALL OTHER SCRIPTS ARE IN SAME DIRECTORY AS CODE, OR THAT PATH IS
# CHANGED

import facial_expression
import Pre_Processing
import Two_d_cnn
import Video_taking
directoryName = 'C:\\Users\\krith\\Downloads\\EDPWebsite_V11\\EDPWebsite\\translation\\inputVideo'
Video_taking.Video_taking1(directoryName)
shapePredictor = 'shape_predictor_68_face_landmarks.dat'

# name of video file may be different - currently set to test.mp4 in pre-processing program
videoFile =  directoryName + '.avi'

facialCue = facial_landmarks_videos_copy.faceMoves(shapePredictor, videoFile)

print(facialCue)
Pre_Processing.processVideo(videoFile, 'processedvideo', 30, 36, 1)
#facial_cue : headshake, eyebrow_raised, frowning
sign = Two_d_cnn.twoDCNN(videoFile)

if facialCue == 'shakeNeutral':
    translation = 'not' + sign
    print(translation)
    #return translation

elif facialCue == 'neutralRaised':
    translation = sign + '?'
    print(translation)
    #return translation

elif facialCue == 'shakeRaised':
    translation = 'not' + sign + '?'
    print(translation)
    #return translation

elif sign == 'What' and facialCue == 'neutralFrown':
    translation = sign + '?'
    print(translation)
    #return translation
else:
    translation = sign
    print(translation)
    #return translation
