from django.apps import AppConfig


class CalibrationConfig(AppConfig):
    name = 'calibration'
