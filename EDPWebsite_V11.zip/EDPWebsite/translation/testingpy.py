def addition(a, b):
    return a+b

def additionVersionTwo(a, b, c, d):
    return a+b+c+d
