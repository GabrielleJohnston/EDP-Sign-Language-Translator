import os, sys
import numpy as np
import cv2


def Video_taking1(output_name):



	fourcc = cv2.VideoWriter_fourcc(*'XVID')
	cap = cv2.VideoCapture(0)
	#fps = cap.get(cv2.CAP_PROP_FPS)
	fps2 = 30
	ret, frame = cap.read()
	height = frame.shape[0]
	width = frame.shape[1]
	output_name += ".avi"
	out = cv2.VideoWriter(output_name , fourcc, fps2, (width, height))

	frame_counter = 1

	while (ret == True and frame_counter <= 4*fps2):
		out.write(frame)
		ret, frame = cap.read()
		frame_counter += 1

	out.release()
	cap.release()
	cv2.destroyAllWindows()
