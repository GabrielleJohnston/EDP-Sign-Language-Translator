# USAGE
# python facial_landmarks_video.py --shape-predictor shape_predictor_68_face_landmarks.dat --video video.mp4

# currently infinite loop
def faceDetected(string):

    from imutils.video import VideoStream
    from imutils import face_utils
    import numpy as np
    import datetime
    import argparse
    import imutils
    import time
    import dlib
    import cv2

    # set arguments required to run program - see USAGE above
    # --shape-predictor refers to the trained model referred to to map the facial landmarks
    ap = argparse.ArgumentParser()
    ap.add_argument(string)
    ap.add_argument("-r", "--picamera", type = int, default = -1,
        help = "whether not the Rapsberry Pi camera should be used")
    args = vars(ap.parse_args())

    # start the file video stream
    vs = VideoStream(usePiCamera = args["picamera"] > 0).start()

    # initialize dlib's face detector (HOG-based) and then create
    # the facial landmark predictor
    # detector is the initialised pre-trained detector from dlib, based on HOG standard

    # detector is now the face detector model
    detector = dlib.get_frontal_face_detector()

    # loop over the frames from the video stream
    while True:

    	# grab the frame from the threaded video file stream, resize it to
    	# have a maximum width of 400 pixels, and convert it to
    	# grayscale
        frame = vs.read()
        frame = imutils.resize(frame, width=400)
        grayscaleFrame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        faces = detector(grayscaleFrame, 0)

        if len(faces) > 0:
            print("face found")
            found = 'True'
            cv2.destroyAllWindows()
            vs.stop()
            return found
        else:
            print("face not found")
            found = 'False'
            cv2.destroyAllWindows()
            vs.stop()
            return found
