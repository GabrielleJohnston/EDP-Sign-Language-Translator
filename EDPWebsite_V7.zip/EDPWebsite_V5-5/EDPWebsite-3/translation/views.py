from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from .models import Video

def translation(request):
    return render(request, 'translation.html');

def index(request):
    return HttpResponse('<h1>This is the translation page</h1>')
