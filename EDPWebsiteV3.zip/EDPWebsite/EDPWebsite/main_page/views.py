from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse

def index(request):
    return HttpResponse('<h1>This is the main page</h1>')

#def calibrate(request, page_name):
#    return HttpResponse("<h2>Calibration page </h2>")
