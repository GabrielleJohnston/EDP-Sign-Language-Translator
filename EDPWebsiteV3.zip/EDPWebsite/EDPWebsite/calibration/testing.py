print("Hello world")

def addition(a, b):
    return a+b

def subtration(a, b):
    return a-b
