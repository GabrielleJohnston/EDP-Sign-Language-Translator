from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from .models import Picture

from . import testing

def index(request):
    a = Picture.objects.all()
    html = ""
    counter = 0
    x = testing.addition(1, 5)
    if len(a) == 0:
        html += "<h2>Please readjust position so that both your hands and face can be captured by the camera.</h2>"+str(x)
    else:
        if a[0].faceExists == True:
            counter += 1
        if a[0].handExists == True:
            counter += 1
        if counter == 2:
            html = ""

            html += '<h2>You may proceed to the Translation page!</h2>'
            Picture.objects.all().delete()
        else:
            html = ""
            html += "<h2>Please readjust position so that both your hands and face can be captured by the camera.</h2>"
            Picture.objects.all().delete()
    return HttpResponse(html)
