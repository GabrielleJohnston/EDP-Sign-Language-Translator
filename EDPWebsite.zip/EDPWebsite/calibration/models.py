from django.db import models
#This is a model for both my database and my python code
#make a class - each variable in class is converted to a column in database
# Create your models here.
class Picture(models.Model):
    image = models.ImageField(upload_to='pictures/', width_field = 'picture_width' , height_field = 'picture_height', max_length=255)
    faceExists = models.BooleanField(default = False) #program will take image in. Will run shape predictor model on it - access
    #the coordinates from the shape predictor model - if there are 68 facial landmarks - face exists. Access this variable from
    #database and change the value to true
    handExists = models.BooleanField(default = False)

    def __str__(self):
        return "Face exists: " + str(self.faceExists) + " Hand Exists: " + str(self.handExists)
