#This file says look at whatever url the person requested and perform some
#functionality
from django.conf.urls import include, url
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static

from main_page import views

#NOTE - Each URL is connected to a view, which is connected to an html response
urlpatterns = [
    url(r'^admin/', admin.site.urls), #r signifies regular expressions,
    url(r'^calibration', views.calibration, name='calibration'),
    url(r'^translation', views.translation, name='translation'),
    url(r'^contact_us', views.contact_us, name='contact_us'),
    url(r'^', views.landing, name='landing'),
    url(r'^/about_us', views.about_us, name='about_us'),

]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root= settings.STATIC_URL)
    urlpatterns += static(settings.MEDIA_URL, document_root= settings.MEDIA_URL)
