#This file says look at whatever url the person requested and perform some
#functionality
from django.conf.urls import include, url
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static

#NOTE - Each URL is connected to a view, which is connected to an html response
urlpatterns = [
    url(r'^admin/', admin.site.urls), #r signifies regular expressions,
    url(r'^main_page/contact_us/', include('contact_us.urls')),
    url(r'^main_page/', include('main_page.urls')),
    url(r'^main_page/about_us/', include('about_us.urls')),
    url(r'^main_page/calibration/', include('calibration.urls')),
    url(r'^main_page/calibration/translation/', include('translation.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root= settings.STATIC_URL)
    urlpatterns += static(settings.MEDIA_URL, document_root= settings.MEDIA_URL)
