from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse

def landing(request):
    return render(request, 'landing.html');

def contact_us(request):
    return render(request, 'contact_us.html');

def about_us(request):
    return render(request, 'about_us.html');

def translation(request):
    return render(request, 'translation.html');

def calibration(request):
        return render(request, 'calibration.html');

def index(request):
    return HttpResponse('<h1>This is the main page</h1>')
