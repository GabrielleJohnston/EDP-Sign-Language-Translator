from django.shortcuts import render
#functions that take a user request and give them back something
# Create your views here.
from django.http import HttpResponse

def contact_us(request):
    return render(request, 'contact_us.html');

def index(request):
    return HttpResponse('<h1>This is the contact us page</h1>')
