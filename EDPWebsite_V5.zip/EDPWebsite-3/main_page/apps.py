from django.apps import AppConfig


class MainPageConfig(AppConfig):
    name = 'main_page'
