from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from .models import Picture
from . import faceExists
def calibration(request):
    while(True):
        return render(request, 'calibration.html', {'FaceExists':faceExists.faceDetected('shape_predictor_68_face_landmarks.dat')});

def index(request):
    a = Picture.objects.all()
    html = ""
    counter = 0
    if len(a) == 0:
        html += "<h2>Please readjust position so that both your hands and face can be captured by the camera.</h2>"
    else:
        if a[0].faceExists == True:
            counter += 1
        if a[0].handExists == True:
            counter += 1
        if counter == 2:
            html = ""

            html += '<h2>You may proceed to the Translation page!</h2>'
            Picture.objects.all().delete()
        else:
            html = ""
            html += "<h2>Please readjust position so that both your hands and face can be captured by the camera.</h2>"
            Picture.objects.all().delete()
    return render(request, 'calibration.html')
